package de.snake.doit.protocol;

import de.snake.doit.protocol.interfaces.LobbyProtocol;
import de.snake.doit.util.Util;

import java.io.Serializable;
import java.net.*;

public class MulticastServerToClient implements LobbyProtocol, Serializable {
    private String lobbyName;
    private String ipAddressFromLobbyHost;
    private int lobbyMembersJoined;

    public MulticastServerToClient(String lobbyName, int lobbyMembersJoined) {
        this.lobbyName = lobbyName;
        this.ipAddressFromLobbyHost = Util.lookUpOwnIpAddress();
        this.lobbyMembersJoined = lobbyMembersJoined;
    }

    public String getLobbyName() {
        return lobbyName;
    }

    public String getIpAddressFromLobbyHost() {
        return ipAddressFromLobbyHost;
    }

    public int getLobbyMembersJoined() {
        return lobbyMembersJoined;
    }

}
