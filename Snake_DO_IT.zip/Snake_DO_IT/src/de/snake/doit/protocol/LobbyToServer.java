package de.snake.doit.protocol;

import de.snake.doit.protocol.interfaces.LobbyProtocol;
import de.snake.doit.protocol.objects.LobbyPlayer;

import java.io.Serializable;
import java.util.HashMap;

public class LobbyToServer implements LobbyProtocol, Serializable {
    private LobbyPlayer ownPlayer;
    private boolean leaveLobby;
    private boolean closeLobby;
    private Boolean gameStart;


    public Boolean isGameStart() {
        return gameStart;
    }

    public LobbyPlayer getOwnPlayer() {
        return ownPlayer;
    }

    public boolean isLeaveLobby() {
        return leaveLobby;
    }
    public boolean isCloseLobby(){
        return closeLobby;
    }

    public void setCloseLobby(boolean closeLobby) {
        this.closeLobby = closeLobby;
    }

    public LobbyToServer(LobbyPlayer ownPlayer, boolean leaveLobby, Boolean gameStart) {
        this.ownPlayer = ownPlayer;
        this.leaveLobby = leaveLobby;
        this.gameStart = gameStart;
    }
}
