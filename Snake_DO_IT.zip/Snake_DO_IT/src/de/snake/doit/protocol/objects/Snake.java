package de.snake.doit.protocol.objects;

import de.snake.doit.protocol.enums.Directions;

import java.awt.*;
import java.util.ArrayList;

public class Snake {
    private ArrayList<Point> snakeElements;
    private int length;
    private int gameScore;
    private boolean wonGame;
    private boolean gameOver;
    private int slotID;

    public Snake(int length, int startPosition) {
        this.snakeElements = new ArrayList<>();
        this.gameScore = 0;
        this.wonGame = false;
        this.gameOver = false;
        this.slotID = startPosition;
        switch (startPosition){
            case 1:
                this.snakeElements.add(new Point(10,19));
                break;
            case 2:
                this.snakeElements.add(new Point(0,10));
                break;
            case 3:
                this.snakeElements.add(new Point(19,10));
                break;
            case 4:
                this.snakeElements.add(new Point(10,0));
                break;
        }
        this.length = length;
    }
    public ArrayList<Point> getSnakeElements() {
        return snakeElements;
    }
    public boolean isGameOver() {
        return gameOver;
    }
    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }
    public int getGameScore() {
        return gameScore;
    }
    public int getSlotID() {
        return slotID;
    }

    public void moveAndEaten(Directions direction, boolean eaten){
        if (this.gameOver){
            snakeElements.clear();
            return;
        }
        if (eaten){
            switch (direction){
                case UP -> {
                                    this.snakeElements.add(
                                    new Point(snakeElements.get(snakeElements.size()-1).x,
                                    snakeElements.get(snakeElements.size()-1).y-1)
                                    );
                                    gameScore += 100;
                }
                case DOWN -> {
                                    this.snakeElements.add(
                                    new Point(snakeElements.get(snakeElements.size()-1).x,
                                    snakeElements.get(snakeElements.size()-1).y+1)
                                    );
                                    gameScore += 100;
                }
                case LEFT -> {
                                    this.snakeElements.add(
                                    new Point(snakeElements.get(snakeElements.size()-1).x-1,
                                    snakeElements.get(snakeElements.size()-1).y)
                                    );
                                    gameScore += 100;
                }
                case RIGHT -> {
                                    this.snakeElements.add(
                                    new Point(snakeElements.get(snakeElements.size()-1).x+1,
                                    snakeElements.get(snakeElements.size()-1).y)
                                    );
                                    gameScore += 100;
                }
            }
        }else{
            switch (direction){
                case UP ->      {
                                    this.snakeElements.add(
                                    new Point(snakeElements.get(snakeElements.size()-1).x,
                                    snakeElements.get(snakeElements.size()-1).y-1)
                                    );
                                    this.snakeElements.remove(0);
                                }
                case DOWN ->    {
                                    this.snakeElements.add(
                                    new Point(snakeElements.get(snakeElements.size()-1).x,
                                    snakeElements.get(snakeElements.size()-1).y+1)
                                    );
                                    this.snakeElements.remove(0);
                                }
                case LEFT ->    {
                                    this.snakeElements.add(
                                    new Point(snakeElements.get(snakeElements.size()-1).x-1,
                                    snakeElements.get(snakeElements.size()-1).y)
                                    );
                                    this.snakeElements.remove(0);
                                }
                case RIGHT ->   {
                                    this.snakeElements.add(
                                    new Point(snakeElements.get(snakeElements.size()-1).x+1,
                                    snakeElements.get(snakeElements.size()-1).y)
                                    );
                                    this.snakeElements.remove(0);
                                }
            }
        }
    }
}
