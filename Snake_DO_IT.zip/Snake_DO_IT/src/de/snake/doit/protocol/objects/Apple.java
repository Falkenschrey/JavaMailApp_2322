package de.snake.doit.protocol.objects;

import java.awt.*;
import java.util.HashMap;
import java.util.Random;

public class Apple {
    private Point apple;

    public Apple(){
        this.apple = new Point(0,0);
    }

    public Point getApple() {
        return apple;
    }

    public Point generateApplePoint(HashMap<String,Snake> snakes){
        Point newApple = new Point();
        newApple.x = new Random().nextInt(19);
        newApple.y = new Random().nextInt(19);
        for (HashMap.Entry<String, Snake> set : snakes.entrySet()) {
            for (Point pointSnake : set.getValue().getSnakeElements()){
                if (newApple.x == pointSnake.x && newApple.y == pointSnake.y){
                    System.out.println("Punkt gleich!");
                    return generateApplePoint(snakes);
                }
            }
        }
        this.apple = newApple;
        return newApple;
    }
}
