package de.snake.doit.protocol.objects;

import java.io.Serializable;
import java.util.Random;

public class LobbyPlayer implements Serializable {
    private String playerName;
    private String ipAddress;
    private boolean ready;
    private boolean inGame;

    public boolean isInGame() {
        return inGame;
    }

    public void setInGame(boolean inGame) {
        this.inGame = inGame;
    }

    public LobbyPlayer(String playerName, boolean ready) {
        this.playerName = playerName;
        this.ready = ready;
        this.inGame = false;
    }

    public boolean isReady() {
        return ready;
    }

    public void setReady(boolean ready) {
        this.ready = ready;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getIpAddress() {
        return ipAddress;
    }
}
