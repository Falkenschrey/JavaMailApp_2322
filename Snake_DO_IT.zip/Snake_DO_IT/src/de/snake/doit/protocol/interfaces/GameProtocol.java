package de.snake.doit.protocol.interfaces;

public interface GameProtocol {
}
