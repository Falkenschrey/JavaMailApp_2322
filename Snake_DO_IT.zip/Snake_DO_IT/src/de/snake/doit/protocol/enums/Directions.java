package de.snake.doit.protocol.enums;

public enum Directions {
    UP,DOWN,LEFT,RIGHT
}
