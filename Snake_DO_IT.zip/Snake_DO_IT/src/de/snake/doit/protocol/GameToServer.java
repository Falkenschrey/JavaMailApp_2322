package de.snake.doit.protocol;

import de.snake.doit.protocol.enums.Directions;
import de.snake.doit.protocol.interfaces.GameProtocol;

import java.io.Serializable;

public class GameToServer implements Serializable, GameProtocol {
    private boolean isSinglePlayer;
    private boolean isMultiPlayer;
    private Directions direction;
    private boolean readyForGamestartFlag;
    private int slotID;


    private GameToServer(){

    }

    public GameToServer(Directions direction, boolean isSinglePlayer, int slotID){
        this();
        this.direction = direction;
        this.readyForGamestartFlag = false;
        this.isSinglePlayer = isSinglePlayer;
        this.slotID = slotID;
        if (!this.isSinglePlayer){
            this.isMultiPlayer = true;
        }
    }
    public static GameToServer generateInitialSinglePlayerPackage(int slotID){
        System.out.println("[GameToServer]Generate Initital SinglePlayer Package");
        GameToServer gameToServer = new GameToServer();
        gameToServer.readyForGamestartFlag = true;
        gameToServer.isSinglePlayer = true;
        gameToServer.direction = Directions.UP;
        gameToServer.slotID = slotID;
        return gameToServer;
    }

    public static GameToServer generateInitialMultiplayerPackage(Directions direction, int slotID){
        GameToServer gameToServer = new GameToServer();
        gameToServer.readyForGamestartFlag = true;
        gameToServer.isSinglePlayer = false;
        gameToServer.isMultiPlayer = true;
        gameToServer.direction = direction;
        gameToServer.slotID = slotID;
        return gameToServer;
    }
    public int getSlotID() {
        return slotID;
    }

    public void setSlotID(int slotID) {
        this.slotID = slotID;
    }

    public boolean isSinglePlayer() {
        return this.isSinglePlayer;
    }

    public boolean isMultiPlayer() {
        return isMultiPlayer;
    }

    public Directions getDirection() {
        return this.direction;
    }

    public boolean isReadyForGamestartFlag() {
        return this.readyForGamestartFlag;
    }
}
