package de.snake.doit.protocol;

import de.snake.doit.protocol.interfaces.GameProtocol;

import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class GameToClient implements Serializable, GameProtocol {
    private HashMap<Integer, ArrayList<Point>> renderSnakes;
    private Point renderApple;
    private HashMap<Integer, Boolean> gameOverFlag;
    private HashMap<Integer, Integer> gameScore;
    private boolean startGameFlag;

    public GameToClient() {
        this.renderSnakes = new HashMap<>();
        this.gameOverFlag = new HashMap<>();
        this.gameScore = new HashMap<>();
    }

    public HashMap<Integer, ArrayList<Point>> getRenderSnake() {
        return renderSnakes;
    }

    public Point getRenderApple() {
        return renderApple;
    }

    public boolean isGameOverFlag(int slotID) {
        return gameOverFlag.get(slotID);
    }

    public int getGameScore(int slotID) {
        return gameScore.get(slotID);
    }

    public void setGameScore(int slotID,int gameScore) {
        this.gameScore.put(slotID, gameScore);
    }

    public void setRenderSnake(int slotID ,ArrayList<Point> renderSnake) {
        this.renderSnakes.put(slotID,renderSnake);
    }

    public void setRenderApple(Point renderApple) {
        this.renderApple = renderApple;
    }

    public void setGameOverFlag(int slotID,boolean gameOverFlag) {
        this.gameOverFlag.put(slotID, gameOverFlag);
    }

    public void setStartGameFlag(boolean startGameFlag) {
        this.startGameFlag = startGameFlag;
    }
}
