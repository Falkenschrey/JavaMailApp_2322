package de.snake.doit.protocol;

import de.snake.doit.protocol.interfaces.LobbyProtocol;
import de.snake.doit.protocol.objects.LobbyPlayer;

import java.io.Serializable;
import java.util.HashMap;

public class LobbyToClient implements Serializable, LobbyProtocol {
    private HashMap<Integer, LobbyPlayer> joinedPlayers;
    private LobbyPlayer hostPlayer;
    private String lobbyName;
    private boolean lobbyClose;
    private boolean gameStart;
    private boolean lobbyInGame;



    public LobbyToClient(HashMap<Integer, LobbyPlayer> joinedPlayers, LobbyPlayer hostPlayer, String lobbyName, boolean lobbyClose, boolean gameStart, boolean lobbyInGame) {
        this.joinedPlayers = joinedPlayers;
        this.hostPlayer = hostPlayer;
        this.lobbyName = lobbyName;
        this.lobbyClose = lobbyClose;
        this.gameStart = gameStart;
        this.lobbyInGame = lobbyInGame;
    }
    public String getLobbyName() {
        return lobbyName;
    }
    public HashMap<Integer, LobbyPlayer> getJoinedPlayers() {
        return joinedPlayers;
    }

    public boolean isLobbyClose() {
        return lobbyClose;
    }

    public LobbyPlayer getHostPlayer() {
        return hostPlayer;
    }

    public boolean isGameStart() {
        return gameStart;
    }
    public void setGameStart(boolean gameStart) {
        this.gameStart = gameStart;
    }
    public boolean isLobbyInGame() {
        return lobbyInGame;
    }
}
