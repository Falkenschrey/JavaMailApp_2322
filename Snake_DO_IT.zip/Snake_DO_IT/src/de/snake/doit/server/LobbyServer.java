package de.snake.doit.server;

import de.snake.doit.client.LobbyClient;
import de.snake.doit.protocol.LobbyToClient;
import de.snake.doit.protocol.LobbyToServer;
import de.snake.doit.protocol.MulticastServerToClient;
import de.snake.doit.protocol.interfaces.LobbyProtocol;
import de.snake.doit.util.Util;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class LobbyServer {
    private ServerSocket serverSocket;
    private MulticastServer multicastServer;
    private LobbyServerHandler lobbyServerHandler;
    private String lobbyName;
    private final ScheduledExecutorService threadService = Executors.newScheduledThreadPool(2);

    //ServerSocket mit Port 666 öffnen
    public LobbyServer(String lobbyName, String hostIP) throws IOException {
        this.lobbyName = lobbyName;
        System.out.println("[Lobby-Server]Serverstart");
        this.serverSocket = new ServerSocket(667);
        this.lobbyServerHandler = new LobbyServerHandler(hostIP,lobbyName);
        start();
    }

    //Schleife um neue Verbindungen anzunehmen
    //Übergabe des Sockets und des ThreadServices für multiple Clients
    public void start() throws IOException {
        System.out.println("[Lobby-Server]Listening");
        threadService.schedule(listenForConnections,0,TimeUnit.MILLISECONDS);
        threadService.scheduleAtFixedRate(multiCastLobby,0,100, TimeUnit.MILLISECONDS);
    }
    Runnable listenForConnections = new Runnable() {
        @Override
        public void run() {
            while (true) {
                try {
                    if (lobbyServerHandler.getClientsConnected() == 4){
                        break;
                    }
                    new ConnectionHandler(serverSocket.accept(), lobbyServerHandler);
                    lobbyServerHandler.addConnection();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    };

    Runnable multiCastLobby = new Runnable() {
        @Override
        public void run() {
            try {
                if (lobbyServerHandler.isLobbyClose()){
                    threadService.shutdown();
                    serverSocket.close();
                    return;
                }
                multicastServer = new MulticastServer();
                multicastServer.sendMulticastLobbyToClients(new MulticastServerToClient(lobbyName,lobbyServerHandler.getClientsConnected()));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    };

    private class ConnectionHandler {
        private Socket clientSocket;
        private LobbyServerHandler lobbyServerHandler;

        public ConnectionHandler(Socket socket, LobbyServerHandler lobbyServerHandler){
            this.clientSocket = socket;
            this.lobbyServerHandler = lobbyServerHandler;

            //Starten des Threads, wenn Verbindung zustande kommt
            ScheduledExecutorService threadService = Executors.newScheduledThreadPool(2);
            threadService.schedule(run,0,TimeUnit.MILLISECONDS);
        }
        Runnable run = () -> {
            try {
                System.out.println("[Lobby-Server]Connection found!");
                ObjectInputStream objectInputStream = new ObjectInputStream(clientSocket.getInputStream());
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(clientSocket.getOutputStream());
                System.out.println("[Lobby-Server]Connected with " + clientSocket.getRemoteSocketAddress());
                boolean isLeaveLobby = false;
                while (!isLeaveLobby) {
                    LobbyToServer lobbyToServer = (LobbyToServer) objectInputStream.readObject();
                    if (lobbyToServer.isCloseLobby()){
                        lobbyServerHandler.setLobbyClose(true);
                    }
                    if (lobbyToServer.isGameStart() != null){
                        lobbyServerHandler.setGameStart(lobbyToServer.isGameStart());
                    }

                    lobbyServerHandler.handlePlayer(lobbyToServer.getOwnPlayer(),Util.getIpAddressFromByteArray(clientSocket.getInetAddress().getAddress()),lobbyToServer.isLeaveLobby(),clientSocket);
                    isLeaveLobby = lobbyToServer.isLeaveLobby();

                    LobbyToClient lobbyToClient = lobbyServerHandler.currentState();
                    objectOutputStream.writeObject(lobbyToClient);

//                    objectOutputStream.writeObject(lobbyServerHandler.currentState());
                    objectOutputStream.flush();
                }
                objectOutputStream.close();
                objectOutputStream.close();
                clientSocket.close();
            } catch (IOException | ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        };
    }
}
