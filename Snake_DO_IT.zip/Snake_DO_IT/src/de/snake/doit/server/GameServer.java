package de.snake.doit.server;


import de.snake.doit.protocol.GameToServer;
import de.snake.doit.protocol.interfaces.GameProtocol;
import de.snake.doit.protocol.GameToClient;
import de.snake.doit.util.Globals;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class GameServer  {
    private ServerSocket serverSocket;
    private boolean singlePlayer;
    private int connectedPlayers;
    private GameServerHandler gameServerHandler;
    private final ScheduledExecutorService threadService = Executors.newScheduledThreadPool(0);

    //ServerSocket mit Port 666 öffnen
    public GameServer(boolean singlePlayer, int connectedPlayers) throws IOException {
        Globals.setGameServerRunning(true);
        System.out.println("[Server]Serverstart");
        this.serverSocket = new ServerSocket(666);
        this.singlePlayer = singlePlayer;
        this.connectedPlayers = connectedPlayers;
        this.gameServerHandler = new GameServerHandler(connectedPlayers);
        start();
    }
    //Schleife um neue Verbindungen anzunehmen
    //Übergabe des Sockets und des ThreadServices für multiple Clients
    public void start() throws IOException{
        System.out.println("[Server]Listening");
        threadService.schedule(listenForConnections,0,TimeUnit.MILLISECONDS);
    }

    Runnable listenForConnections = new Runnable() {
        @Override
        public void run() {
            while (true){
                try {
                    new ConnectionHandler(serverSocket.accept(), gameServerHandler, singlePlayer);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("[GameServer]Verbindung bekommen");
            }
        }
    };

    //Server stoppen
    public void stop() throws IOException {
        serverSocket.close();
    }

    private class ConnectionHandler {
        private Socket clientSocket;
        private GameServerHandler gameServerHandler;
        private boolean singlePlayer;

        public ConnectionHandler(Socket socket, GameServerHandler gameServerHandler, boolean singlePlayer){
            this.clientSocket = socket;
            this.gameServerHandler = gameServerHandler;
            this.singlePlayer = singlePlayer;

            //Eigener ThreadService
            ScheduledExecutorService threadService = Executors.newScheduledThreadPool(2);
            threadService.schedule(run,0, TimeUnit.MILLISECONDS);
        }
        Runnable run = () -> {
            try {
                System.out.println("[Server]Connection found!");

                ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
                ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());

                System.out.println("[Server]Connected with " + clientSocket.getRemoteSocketAddress());
//                gameServerHandler.addConnection();

                while (true) {
                    //Empfange GameToServer Objekt
                    System.out.println("[GAMESERVER] EMPFANGE");
                    Object object = in.readObject();
                    System.out.println("[GAMESERVER] EMPFANGEN ERFOLGREICH");
                    if (object instanceof Serializable && object instanceof GameProtocol){
                        gameServerHandler.input(clientSocket,object);
                    }
                    //Sende ToClient Objekt
                    if (singlePlayer){
                        GameToClient gameToClient = (GameToClient) gameServerHandler.getOutput(clientSocket);
                        out.writeObject(gameToClient);
                        out.flush();
                        out.reset();
                        if (gameToClient.isGameOverFlag(1)){
                            in.close();
                            out.close();
                            clientSocket.close();
                            serverSocket.close();
                            break;
                        }
                    } else {
                        while (true){
                            GameToClient gameToClient = (GameToClient) gameServerHandler.getOutput(clientSocket);
                            if (gameToClient == null){
                                continue;
                            }
                            System.out.println("[GAMESERVER] SENDE");
                            out.writeObject(gameToClient);
                            System.out.println("[GAMESERVER] GESENDET");
                            out.flush();
                            out.reset();
                            break;
                        }



//                        System.out.println("[GAMESERVER] SCHLAFE");
//                        int tick = 1;
//                        while (!gameServerHandler.isReadyToSend()){
//                            System.out.println("[GAMESERVER] Tick " + tick);
//                            tick++;
//                        }
//                        System.out.println("[GAMESERVER] SCHLAF BEENDET");
//                        GameToClient gameToClient = (GameToClient) gameServerHandler.getOutput(clientSocket);
//                        System.out.println("[GAMESERVER] SENDE");
//                        out.writeObject(gameToClient);
//                        System.out.println("[GAMESERVER] GESENDET");
//                        out.flush();
//                        out.reset();
                    }
                }
            } catch (IOException | InterruptedException | ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        };
    }
}
