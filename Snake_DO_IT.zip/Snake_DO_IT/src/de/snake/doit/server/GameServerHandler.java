package de.snake.doit.server;

import de.snake.doit.protocol.*;
import de.snake.doit.protocol.objects.Apple;
import de.snake.doit.protocol.objects.Snake;
import de.snake.doit.util.Globals;

import java.awt.*;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

public class GameServerHandler {
    private int connectionsTogether;
    private int connectionsAlreadyGot;
    private HashMap<String, GameToServer> input;
    private HashMap<String, GameToClient> output;
    private HashMap<String,Snake> snakes;
    private Apple apple;
    private boolean closedConnection;
    private HashMap<String,Integer> slotIDHashMap;

    public boolean isClosedConnection() {
        return closedConnection;
    }

    private boolean readyToSend;

    public GameServerHandler(int connectedPlayers){
        this.connectionsTogether = connectedPlayers;
        this.connectionsAlreadyGot = 0;
        this.readyToSend = false;
        this.closedConnection = false;
        this.apple = new Apple();
        this.input = new HashMap<>();
        this.output = new HashMap<>();
        this.snakes = new HashMap<>();
        this.slotIDHashMap = new HashMap<>();
    }

    public boolean isReadyToSend() {
        return readyToSend;
    }


//    public void addConnection(){
//        this.connectionsTogether += 1;
//    }
//
//    public void removeConnection(){
//        this.connectionsTogether -= 1;
//    }

    public void input(Socket clientSocket, Object object) {
        input.put(clientSocket.getRemoteSocketAddress().toString(),(GameToServer) object);
        slotIDHashMap.put(clientSocket.getRemoteSocketAddress().toString(),((GameToServer) object).getSlotID());
        connectionsAlreadyGot++;
//        System.out.println("[GAMESERVERHANDLER] VERBINDUNGEN BEKOMMEN" + connectionsAlreadyGot);
//        System.out.println("[GAMESERVERHANDLER] CONNECTIONSTOGETHER" + connectionsTogether);
//        if (connectionsTogether == connectionsAlreadyGot){
//            System.out.println("[GAMESERVERHANDLER] GENERIERE OBJEKTE");
//            generateToClientObjectsFromHashMap(clientSocket);
//
//            this.readyToSend = true;
//        }
    }

    private void generateToClientObjectsFromHashMap(Socket clientSocket){
        input.forEach((localAddress, gameToServer) -> {
            if (gameToServer.isSinglePlayer()){
                if (gameToServer.isReadyForGamestartFlag()){
                    output.put(localAddress,generateSinglePlayerGameStartToClientObject(localAddress, gameToServer.getSlotID()));
                } else {
                    try {
                        output.put(localAddress,generateInGameToClientObject(localAddress,clientSocket, gameToServer.getSlotID()));
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }else if (gameToServer.isMultiPlayer()){
                if (gameToServer.isReadyForGamestartFlag()){
                    output.put(localAddress,generateMultiPlayerGameStartToClientObject(localAddress, gameToServer.getSlotID()));
                } else {
                    try {
                        output.put(localAddress,generateInGameToClientObject(localAddress,clientSocket,gameToServer.getSlotID()));
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }

            }
        });
    }

    private GameToClient generateInGameToClientObject(String localAddress, Socket clientSocket, int slotID) throws IOException {
        Snake snake = snakes.get(localAddress);
        GameToServer gameToServer = input.get(localAddress);
        GameToClient gameToClient = new GameToClient();
        gameToClient.setStartGameFlag(false);
        gameToClient.setGameOverFlag(slotID,false);
        if (connectionsTogether == 1){
            checkGameOverSituationSinglePlayer(localAddress);
        } else {
            //MultiplayerGameOver!
        }
        if (snake.isGameOver()){
            gameToClient.setGameScore(slotID,snake.getGameScore());
            gameToClient.setGameOverFlag(slotID,true);
            if (connectionsTogether == 1){
                this.closedConnection = true;
                Globals.setGameServerRunning(false);
            }
            return gameToClient;
        } else {
            gameToClient.setRenderApple(apple.getApple());
        }
        snake.moveAndEaten(gameToServer.getDirection(),checkIfEaten(localAddress));
        snakes.forEach((clientAddress,snakeObject) -> {
            gameToClient.setRenderSnake(slotIDHashMap.get(clientAddress),snakeObject.getSnakeElements());
        });
        gameToClient.setGameScore(slotID,snake.getGameScore());
        return gameToClient;
    }

    private void checkGameOverSituationSinglePlayer(String clientAdress) {
            ArrayList<Point> snakeObjectArrayList = snakes.get(clientAdress).getSnakeElements();
            for (int i = 0; i < snakeObjectArrayList.size(); i++) {
                for (int j = 0; j < snakeObjectArrayList.size(); j++) {
                    if (snakeObjectArrayList.get(i).x == snakeObjectArrayList.get(j).x &&
                            snakeObjectArrayList.get(i).y == snakeObjectArrayList.get(j).y &&
                            i != j){
                        snakes.get(clientAdress).setGameOver(true);
                    }
                }
                if (snakeObjectArrayList.get(i).x == -1 ||
                        snakeObjectArrayList.get(i).y == -1 ||
                        snakeObjectArrayList.get(i).x == 20 ||
                        snakeObjectArrayList.get(i).y == 20)
                {
                    snakes.get(clientAdress).setGameOver(true);
                }
            }
    }

    private boolean checkIfEaten(String localAdress) {
        if (snakes.get(localAdress).getSnakeElements().get(snakes.get(localAdress).getSnakeElements().size()-1).x == apple.getApple().x &&
                snakes.get(localAdress).getSnakeElements().get(snakes.get(localAdress).getSnakeElements().size()-1).y == apple.getApple().y){
            apple.generateApplePoint(snakes);
            return true;
        }
        return false;
    }

    private GameToClient generateSinglePlayerGameStartToClientObject(String localAddress, int slotID) {
        Snake snake = new Snake(1,slotID);
        snakes.put(localAddress,snake);
        GameToClient gameToClient = new GameToClient();
        gameToClient.setStartGameFlag(true);
        gameToClient.setRenderApple(apple.generateApplePoint(this.snakes));
        //AB hier geht es nicht weiter
        gameToClient.setRenderSnake(slotID,snake.getSnakeElements());
        gameToClient.setGameOverFlag(slotID,false);
        return gameToClient;
    }

    private GameToClient generateMultiPlayerGameStartToClientObject(String localAddress, int slotID){
        Snake snake = new Snake(1,slotID);
        snakes.put(localAddress,snake);
        GameToClient gameToClient = new GameToClient();
        gameToClient.setStartGameFlag(true);
        gameToClient.setRenderApple(apple.generateApplePoint(this.snakes));
        gameToClient.setRenderSnake(slotID,snake.getSnakeElements());
        gameToClient.setGameOverFlag(slotID,false);
        return gameToClient;
    }

    public Object getOutput(Socket clientSocket) throws InterruptedException {
//        System.out.println("[GAMESERVERHANDLER] CONNECTIONSALREADYGOT " + connectionsAlreadyGot);
        if (connectionsTogether == connectionsAlreadyGot){
            System.out.println("[GAMESERVERHANDLER] GENERIERE OBJEKTE");
            generateToClientObjectsFromHashMap(clientSocket);
            this.connectionsAlreadyGot = 0;
        }

//        this.readyToSend = false;
        return output.get(clientSocket.getRemoteSocketAddress().toString());
    }
}
