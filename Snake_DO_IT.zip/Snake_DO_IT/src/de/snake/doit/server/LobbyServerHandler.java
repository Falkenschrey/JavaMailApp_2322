package de.snake.doit.server;

import de.snake.doit.protocol.LobbyToClient;
import de.snake.doit.protocol.objects.LobbyPlayer;

import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

public class LobbyServerHandler {
    private int clientsConnected = 0;
    private String hostIp;
    private String lobbyName;
    private HashMap<String, LobbyPlayer> joinedPlayers;
    private boolean lobbyClose;
    private boolean gameStart;
    private boolean lobbyInGame;



    public LobbyServerHandler(String hostIP, String lobbyName) {
        this.hostIp = hostIP;
        this.lobbyName = lobbyName;
        this.lobbyClose = false;
        this.joinedPlayers = new HashMap<>();
        this.gameStart = false;
    }
    public void setGameStart(boolean gameStart) {
        this.gameStart = gameStart;
    }

    public int getClientsConnected() {
        return clientsConnected;
    }
    public boolean isLobbyClose() {
        return lobbyClose;
    }

    public void setLobbyClose(boolean lobbyClose) {
        this.lobbyClose = lobbyClose;
    }

    public LobbyToClient currentState() {
        int[] playerCounter = {1};
        HashMap<Integer, LobbyPlayer> currentPlayers = new HashMap<>();
        LobbyPlayer hostPlayer = new LobbyPlayer(joinedPlayers.get(hostIp).getPlayerName(),joinedPlayers.get(hostIp).isReady());
        hostPlayer.setIpAddress(hostIp);
        hostPlayer.setInGame(joinedPlayers.get(hostIp).isInGame());
        currentPlayers.put(playerCounter[0], hostPlayer);
        playerCounter[0]++;
        joinedPlayers.forEach((ipAddress,lobbyPlayer) -> {
            if (!ipAddress.equals(hostIp)){
                LobbyPlayer player = new LobbyPlayer(lobbyPlayer.getPlayerName(),lobbyPlayer.isReady());
                player.setIpAddress(ipAddress);
                player.setInGame(lobbyPlayer.isInGame());
                currentPlayers.put(playerCounter[0],player);
                playerCounter[0]++;
            }
        });
        LobbyToClient lobbyToClient = new LobbyToClient(currentPlayers,joinedPlayers.get(hostIp),lobbyName,lobbyClose, gameStart, lobbyInGame);

        return lobbyToClient;
    }

    public void handlePlayer(LobbyPlayer lobbyPlayer, String ipAddress, boolean isLeaveLobby, Socket clientSocket) throws IOException {
        if (isLeaveLobby){
            lobbyPlayer.setIpAddress(clientSocket.getInetAddress().getHostAddress());
            removeConnection();
            joinedPlayers.remove(lobbyPlayer.getIpAddress());
            return;
        }
        lobbyPlayer.setIpAddress(clientSocket.getInetAddress().getHostAddress());
        joinedPlayers.put(ipAddress,lobbyPlayer);
        testIfSomeoneIsStillInGame();
    }

    private void testIfSomeoneIsStillInGame() {
        boolean[] clientInGameState = {false,false,false,false};
        int[] counter = {0};
        joinedPlayers.forEach((ipAddress,lobbyPlayer) -> {
            clientInGameState[counter[0]] = lobbyPlayer.isInGame();
            counter[0]++;
        });
        lobbyInGame = clientInGameState[0] | clientInGameState[1] | clientInGameState[2] | clientInGameState[3];
    }

    public void addConnection() {
        this.clientsConnected++;
    }
    public void removeConnection(){
        this.clientsConnected--;
    }
}
