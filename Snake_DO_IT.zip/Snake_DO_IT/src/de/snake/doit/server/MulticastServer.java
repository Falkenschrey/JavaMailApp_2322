package de.snake.doit.server;

import de.snake.doit.protocol.MulticastServerToClient;
import de.snake.doit.util.Util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class MulticastServer {

    private final DatagramSocket datagramSocket;
    private DatagramPacket datagramPacket;
    private final ByteArrayOutputStream byteArrayOutputStream;
    private final ObjectOutputStream objectOutputStream;

    private final InetAddress multiCastAddress = findNetworkBroadcastAddress();

    private InetAddress findNetworkBroadcastAddress() throws UnknownHostException {
        String[] splittedAddress = Util.lookUpOwnIpAddress().split("\\.");
        splittedAddress[3] = "255";
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            stringBuilder.append(splittedAddress[i]);
            if (i < 3){
                stringBuilder.append(".");
            }
        }
        return InetAddress.getByName(String.valueOf(stringBuilder));
    }

    public MulticastServer() throws IOException {
        this.datagramSocket = new DatagramSocket();
        this.byteArrayOutputStream = new ByteArrayOutputStream();
        this.objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
    }

    public void sendMulticastLobbyToClients(MulticastServerToClient multicastServerToClient) throws IOException {
        objectOutputStream.writeObject(multicastServerToClient);
//        objectOutputStream.flush();
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        datagramPacket = new DatagramPacket(byteArray, byteArray.length, multiCastAddress, 42420);
        datagramSocket.send(datagramPacket);
        byteArrayOutputStream.close();
        objectOutputStream.close();
        datagramSocket.close();
    }
}
