package de.snake.doit.util;

public class Globals {
    private static String nickname;
    private static boolean gameServerRunning = false;
    private static boolean inGame;

    public static boolean isInGame() {
        return inGame;
    }

    public static void setInGame(boolean inGame) {
        Globals.inGame = inGame;
    }

    public static boolean isGameServerRunning() {
        return gameServerRunning;
    }

    public static void setGameServerRunning(boolean gameServerRunning) {
        Globals.gameServerRunning = gameServerRunning;
    }

    public static void setNickname(String nickname){
        Globals.nickname = nickname;
    }

    public static String getNickname() {
        return nickname;
    }
}
