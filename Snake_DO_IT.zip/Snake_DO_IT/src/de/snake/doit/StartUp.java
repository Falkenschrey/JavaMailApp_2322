package de.snake.doit;

import de.snake.doit.gui.GameStart;
import java.io.IOException;

public class StartUp {
    public static void main(String[] args) throws IOException {
        new GameStart();
    }
}
