package de.snake.doit.gui;

import javax.swing.*;

public class GameFrame extends JFrame {

    public GameFrame(boolean isSinglePlayer){
        if (isSinglePlayer){
            this.setTitle("Snake Singleplayer");
            this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        } else {
            this.setTitle("Snake Multiplayer");
            this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        }
        this.setResizable(false);
        this.setVisible(true);
    }
}
