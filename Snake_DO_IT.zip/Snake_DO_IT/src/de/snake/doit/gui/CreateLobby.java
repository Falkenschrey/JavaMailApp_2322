package de.snake.doit.gui;

import de.snake.doit.client.LobbyClient;
import de.snake.doit.server.LobbyServer;
import de.snake.doit.util.Util;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class CreateLobby extends JFrame {
    private JPanel formCreateLobby;
    private JTextField textFieldName;
    private JButton returnButton;
    private JButton createLobbyButton;


    public CreateLobby() throws IOException {
        this.setTitle("Lobby erstellen");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setContentPane(formCreateLobby);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        createLobbyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!textFieldName.getText().equals("")){
                    try {
                        new LobbyServer(textFieldName.getText(), Util.lookUpOwnIpAddress());
                        new LobbyClient(Util.lookUpOwnIpAddress(),true);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                    CreateLobby.super.dispose();
                } else {
                    JOptionPane.showMessageDialog(CreateLobby.super.getContentPane(),"Bitte Namen eingeben!");
                }
            }
        });
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new SearchLobby();
                } catch (IOException exception) {
                    throw new RuntimeException(exception);
                }
                CreateLobby.super.dispose();
            }
        });
    }
}
