package de.snake.doit.gui;

import de.snake.doit.client.LobbyClient;
import de.snake.doit.client.SearchLobbyHandler;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

public class SearchLobby extends JFrame {
    private JPanel formSearchLobby;
    private JButton returnButton;
    private JButton createLobbyButton;
    private JList<String> listLobbys;
    private JButton joinButton;
    private JButton buttonDirectConnect;

    public SearchLobby() throws IOException {
        this.setTitle("Lobbys");
        DefaultListModel<String> listModel = new DefaultListModel<>();
        listLobbys.setModel(listModel);
        listLobbys.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        this.setContentPane(formSearchLobby);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);

        final String[] searchLobbyLoading = {"",".","..","...","...."};
        final int[] searchLobbyLoadingCounter = {0};
        Timer timer = new Timer();
        listModel.addElement("Suche nach Lobbys");
        SearchLobbyHandler searchLobbyHandler = new SearchLobbyHandler(listModel);

        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                try {
                    searchLobbyHandler.updateListModel();
                } catch (IOException | ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
                if (searchLobbyLoadingCounter[0] == 5){
                    searchLobbyLoadingCounter[0] = 0;
                }
                listModel.set(listModel.getSize()-1,"Suche nach Lobbys" + searchLobbyLoading[searchLobbyLoadingCounter[0]]);
                searchLobbyLoadingCounter[0]++;
            }
        },0,350);
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new GameStart();
                try {
                    searchLobbyHandler.exit();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }

                SearchLobby.super.dispose();
            }
        });
        createLobbyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new CreateLobby();
                    searchLobbyHandler.exit();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }

                SearchLobby.super.dispose();
            }
        });
        joinButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                    if (searchLobbyHandler.getConnectedClients(listLobbys.getSelectedValue()) == 4){
                        JOptionPane.showMessageDialog(SearchLobby.super.getContentPane(),"Lobby voll! Verbindung nicht möglich.");
                    } else {
                        try {
                            new LobbyClient(searchLobbyHandler.getSelectedLobbyIp(listLobbys.getSelectedValue()),false);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                    SearchLobby.super.dispose();
            }
        });
        listLobbys.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && !e.isConsumed()) {
                    e.consume();
                        if (searchLobbyHandler.getConnectedClients(listLobbys.getSelectedValue()) == 4){
                            JOptionPane.showMessageDialog(SearchLobby.super.getContentPane(),"Lobby voll! Verbindung nicht möglich.");
                        } else {
                            try {
                                new LobbyClient(searchLobbyHandler.getSelectedLobbyIp(listLobbys.getSelectedValue()),false);
                            } catch (IOException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                        SearchLobby.super.dispose();
                }
            }
        });
        buttonDirectConnect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DirectJoinLobby();
                SearchLobby.super.dispose();
            }
        });
    }
}
