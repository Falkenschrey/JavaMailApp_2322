package de.snake.doit.gui;

import de.snake.doit.client.GameClient;
import de.snake.doit.client.LobbyClientHandler;
import de.snake.doit.protocol.LobbyToClient;
import de.snake.doit.protocol.objects.LobbyPlayer;
import de.snake.doit.server.GameServer;
import de.snake.doit.util.Globals;
import de.snake.doit.util.Util;

import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class LoungeLobby extends JFrame implements WindowListener {
    private JPanel formLoungeLobby;
    private JButton returnButton;
    private JButton startGameButton;
    private JTextArea textArea1;
    private JTextArea textArea2;
    private JTextArea textArea3;
    private JTextArea textArea4;
    private JLabel labelLobbyName;
    private JLabel labelLobbyHostName;
    private JLabel labelLobbyHostIp;
    private JLabel labelLobbyIngame;
    private LobbyClientHandler lobbyClientHandler;
    private boolean ready;
    private boolean leaveLobby;
    private LobbyPlayer lobbyPlayer;
    private Timer timer;
    private boolean host;
    private Boolean gameStart;
    private int slotID;
    private boolean firstTimeStart;
    private int[] calculateConnectedPlayers;
    private int connectedPlayers;

    public LoungeLobby(boolean host, LobbyClientHandler lobbyClientHandler) throws IOException {
        this.host = host;
        this.setTitle("Lobby Lounge");
        this.setContentPane(formLoungeLobby);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.setLocationRelativeTo(null);
        textArea1.setEnabled(false);
        textArea2.setEnabled(false);
        textArea3.setEnabled(false);
        textArea4.setEnabled(false);
        textArea1.setDisabledTextColor(Color.black);
        textArea2.setDisabledTextColor(Color.black);
        textArea3.setDisabledTextColor(Color.black);
        textArea4.setDisabledTextColor(Color.black);
        this.pack();
        this.setVisible(true);
        this.leaveLobby = false;
        this.firstTimeStart = true;
        this.calculateConnectedPlayers = new int[] {1};
        this.connectedPlayers = 1;
        addWindowListener(this);
        if (host){
            this.ready = true;
        } else {
            this.ready = false;
        }
        this.lobbyPlayer = new LobbyPlayer(Globals.getNickname(),ready);
        this.timer = new Timer();
        if (!host){
            this.startGameButton.setText("Bereit");
        }
        this.lobbyClientHandler = lobbyClientHandler;
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!host){
                    leaveLobby = true;
                } else {
                    lobbyClientHandler.closeLobby();
                }
            }
        });
        startGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!host){
                    if (ready){
                        ready = false;
                        startGameButton.setText("Bereit");
                    } else {
                        ready = true;
                        startGameButton.setText("Abbrechen");
                    }
                } else {
                    gameStart = true;
                }
            }
        });
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (!host){
                    lobbyPlayer.setReady(ready);
                }
                try {
                    if (leaveLobby){
                        new SearchLobby();
                        LoungeLobby.super.dispose();
                        update(lobbyClientHandler.getUpdates(lobbyPlayer,leaveLobby, gameStart));
                        lobbyClientHandler.leaveLobby();
                        timer.cancel();
                    } else {
                        lobbyPlayer.setInGame(Globals.isInGame());
                        update(lobbyClientHandler.getUpdates(lobbyPlayer,leaveLobby, gameStart));
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        },0,100);
    }

    private void update(LobbyToClient lobbyToClient) throws IOException {
        if (lobbyToClient.isLobbyClose()){
            timer.cancel();
            lobbyClientHandler.leaveLobby();
            new SearchLobby();
            LoungeLobby.super.dispose();
            JOptionPane.showMessageDialog(JOptionPane.getRootFrame(),"Lobby geschlossen!");
            return;
        }
        if (lobbyToClient.isLobbyInGame()){
            labelLobbyIngame.setText("Spiel läuft gerade");
        } else {
            labelLobbyIngame.setText("");
        }
        if (lobbyToClient.isGameStart() && !Globals.isInGame()){
            ScheduledExecutorService threadService = Executors.newScheduledThreadPool(2);
            Runnable gameServer = () -> {
                try {
                    new GameServer(false, connectedPlayers);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            };
            Runnable gameClient = () -> {
                try {
                    new GameClient(lobbyToClient.getHostPlayer().getIpAddress(), 500, false, slotID);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            };
            if (host){
                if (!firstTimeStart){
                    threadService.execute(gameClient);
                    this.gameStart = false;
                    Globals.setInGame(true);
                    this.setVisible(false);
                    firstTimeStart = true;
                }
                threadService.execute(gameServer);
                firstTimeStart = false;
            } else {
                threadService.execute(gameClient);
                Globals.setInGame(true);
                this.setVisible(false);
            }
        }
        labelLobbyName.setText(lobbyToClient.getLobbyName());
        labelLobbyHostName.setText("Hostname: " + lobbyToClient.getHostPlayer().getPlayerName());
        labelLobbyHostIp.setText("Host IP: " + lobbyToClient.getHostPlayer().getIpAddress());
        HashMap<Integer, LobbyPlayer> lobbyPlayersHashMap = lobbyToClient.getJoinedPlayers();
        final boolean[] readyState = {true};
        final int[] textAreaCounter = {1};
        resetTextAreaColors();
        lobbyPlayersHashMap.forEach((playerPlace,lobbyPlayer) -> {
            switch (textAreaCounter[0]){
                case 1:
                    if (Util.lookUpOwnIpAddress().equals(lobbyPlayer.getIpAddress())){
                        slotID = 1;
                    }
                    textArea1.setBackground(Color.green);
                    if (lobbyPlayer.isInGame()){
                        textArea1.setText(lobbyPlayer.getPlayerName() + " | " + lobbyPlayer.getIpAddress() + " | Im Spiel");
                    } else {
                        textArea1.setText(lobbyPlayer.getPlayerName() + " | " + lobbyPlayer.getIpAddress() + " | Bereit");
                    }
                    textArea2.setText("");
                    textArea3.setText("");
                    textArea4.setText("");
                    if ( lobbyToClient.getHostPlayer().getPlayerName().equals(Globals.getNickname()) && lobbyToClient.getHostPlayer().getIpAddress().equals(lobbyClientHandler.getOwnIpAddress()) && !lobbyToClient.isLobbyInGame()){
                        readyState[0] = readyState[0] & lobbyPlayer.isReady();
                        if (calculateConnectedPlayers[0] != 1){
                            startGameButton.setEnabled(readyState[0]);
                        } else {
                            startGameButton.setEnabled(false);
                        }
                    }
                    textAreaCounter[0]++;
                    break;
                case 2:
                    if (Util.lookUpOwnIpAddress().equals(lobbyPlayer.getIpAddress())){
                        slotID = 2;
                    }
                    textArea2.setBackground(Color.blue);
                    setTextAreaContent(lobbyPlayer, textArea2);
                    if (  lobbyToClient.getHostPlayer().getPlayerName().equals(Globals.getNickname()) && lobbyToClient.getHostPlayer().getIpAddress().equals(lobbyClientHandler.getOwnIpAddress()) && !lobbyToClient.isLobbyInGame()){
                        readyState[0] = readyState[0] & lobbyPlayer.isReady();
                        startGameButton.setEnabled(readyState[0]);
                    }
                    textArea3.setText("");
                    textArea4.setText("");
                    textAreaCounter[0]++;
                    calculateConnectedPlayers[0] = 2;
                    break;
                case 3:
                    if (Util.lookUpOwnIpAddress().equals(lobbyPlayer.getIpAddress())){
                        slotID = 3;
                    }
                    textArea3.setBackground(Color.YELLOW);
                    setTextAreaContent(lobbyPlayer, textArea3);
                    if (  lobbyToClient.getHostPlayer().getPlayerName().equals(Globals.getNickname()) && lobbyToClient.getHostPlayer().getIpAddress().equals(lobbyClientHandler.getOwnIpAddress()) && !lobbyToClient.isLobbyInGame()){
                        readyState[0] = readyState[0] & lobbyPlayer.isReady();
                        startGameButton.setEnabled(readyState[0]);
                    }
                    textArea4.setText("");
                    textAreaCounter[0]++;
                    calculateConnectedPlayers[0] = 3;
                    break;
                case 4:
                    if (Util.lookUpOwnIpAddress().equals(lobbyPlayer.getIpAddress())){
                        slotID = 4;
                    }
                    textArea4.setBackground(Color.MAGENTA);
                    setTextAreaContent(lobbyPlayer, textArea4);
                    if (  lobbyToClient.getHostPlayer().getPlayerName().equals(Globals.getNickname()) && lobbyToClient.getHostPlayer().getIpAddress().equals(lobbyClientHandler.getOwnIpAddress()) && !lobbyToClient.isLobbyInGame()){
                        readyState[0] = readyState[0] & lobbyPlayer.isReady();
                        startGameButton.setEnabled(readyState[0]);
                    }
                    calculateConnectedPlayers[0] = 4;
                    break;
            }
        });
        connectedPlayers = calculateConnectedPlayers[0];
    }

    private void resetTextAreaColors() {
        textArea1.setBackground(Color.gray);
        textArea2.setBackground(Color.gray);
        textArea3.setBackground(Color.gray);
        textArea4.setBackground(Color.gray);
    }

    private void setTextAreaContent(LobbyPlayer lobbyPlayer, JTextArea textArea) {
        if (lobbyPlayer.isInGame()){
            textArea.setText(lobbyPlayer.getPlayerName() + " | " + lobbyPlayer.getIpAddress() + " | Im Spiel");
        } else {
            if (lobbyPlayer.isReady()){
                textArea.setText(lobbyPlayer.getPlayerName() + " | " + lobbyPlayer.getIpAddress() + " | Bereit");
            } else {
                textArea.setText(lobbyPlayer.getPlayerName() + " | " + lobbyPlayer.getIpAddress() + " | Nicht Bereit");
            }
        }
    }

    @Override
    public void windowOpened(WindowEvent e) {

    }

    @Override
    public void windowClosing(WindowEvent e) {
        if (!host){
            leaveLobby = true;
        } else {
            lobbyClientHandler.closeLobby();
        }
    }

    @Override
    public void windowClosed(WindowEvent e) {

    }

    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {

    }

    @Override
    public void windowActivated(WindowEvent e) {

    }

    @Override
    public void windowDeactivated(WindowEvent e) {

    }
}
