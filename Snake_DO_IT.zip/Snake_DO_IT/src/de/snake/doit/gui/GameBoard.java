package de.snake.doit.gui;

import de.snake.doit.client.GameClientHandler;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;


public class GameBoard extends JPanel {

    private int size;
    private final GameClientHandler gameClientHandler;
    private javax.swing.Timer timerSwing;
    private JFrame parentFrame;
    private static boolean isRunning = false;

    public GameBoard(int size, GameClientHandler gameClientHandler, boolean isSinglePlayer, JFrame frame, int slotID) throws IOException {
        this.setPreferredSize(new Dimension(501,501));
        this.setBackground(new Color(128, 128, 128));
        this.size = size;
        this.parentFrame = frame;
        this.gameClientHandler = gameClientHandler;

        System.out.println("[GAMEBOARD] SENDE STARTPACKET");
        gameClientHandler.sendStartPackage();
        System.out.println("[GAMEBOARD] STARTPACKET GESENDET");
        repaint();
        ActionListener runAction = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    System.out.println("[GAMEBOARD] TICK");
                    gameClientHandler.sendToServerObject(isSinglePlayer);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                repaint();
            }
        };
        this.timerSwing = new javax.swing.Timer(0,runAction);
        timerSwing.setRepeats(true);
        timerSwing.setDelay(250);
        timerSwing.start();


//        timer = new Timer();
//        timer.scheduleAtFixedRate(new TimerTask() {
//            @Override
//            public void run() {
//                    try {
//                        System.out.println("[GAMEBOARD] TICK");
//                        gameClientHandler.sendToServerObject(isSinglePlayer);
//                    } catch (IOException e) {
//                        throw new RuntimeException(e);
//                    }
//                    repaint();
//                }
//        },0,250);
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        System.out.println("[GAMEBOARD] ZEICHNE");
        super.paintComponent(graphics);
        Graphics2D graphics2D = (Graphics2D) graphics;
        drawGrid(500,graphics2D);

        try {
            render(gameClientHandler.getRenderData(), graphics2D);
        } catch (IOException | ClassNotFoundException | InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println("[GAMEBOARD] ZEICHNEN ABGESCHLOSSEN");
    }
    private void drawGrid(int size, Graphics2D graphics2D) {
        for (int i = 0; i <= 500; i += 25) {
            graphics2D.drawLine(i,0,i,500);
        }
        for (int i = 0; i <= 500; i += 25) {
            graphics2D.drawLine(0,i,500,i);
        }
    }
    private void render(HashMap<Integer, HashMap<Integer, ArrayList<Point>>> renderMap, Graphics2D graphics2D) throws IOException, InterruptedException {
        if (renderMap == null) {
            return;
        }
        if (renderMap.containsKey(3)){
            graphics2D.setColor(Color.DARK_GRAY);
            graphics2D.setFont(new Font("Calibri",Font.BOLD,80));
            FontMetrics fontMetrics = graphics2D.getFontMetrics();
            final int[] x = {((getWidth() - fontMetrics.stringWidth(String.valueOf(renderMap.get(3).get(1).get(0).x))) / 2)};
            int y = ((getHeight() - fontMetrics.getHeight()) / 2) + fontMetrics.getAscent();
            graphics2D.drawString(String.valueOf(renderMap.get(3).get(1).get(0).x), x[0],y);
            x[0] = ((getWidth() - fontMetrics.stringWidth("Punkte")) / 2);
            graphics2D.drawString("Punkte", x[0],y-70);
            x[0] = ((getWidth() - fontMetrics.stringWidth("Game Over")) / 2);
            graphics2D.drawString("Game Over", x[0],y-170);
            timerSwing.stop();
            gameClientHandler.closeConnection();
//            timer.cancel();
            Timer shutdownTimer = new Timer();
            shutdownTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    parentFrame.dispose();
                    new GameStart();
                }
            },5000);
            return;
        }
        renderApple(renderMap.get(1).get(0), graphics2D);
        renderSnakes(renderMap.get(2), graphics2D);
    }

    private void renderSnakes(HashMap<Integer, ArrayList<Point>> hashMapWithArrayListOfSnakePointsInside, Graphics2D graphics2D) {
        hashMapWithArrayListOfSnakePointsInside.forEach((slotID,arrayListWithPoints) -> {
            switch (slotID){
                case 1:
                    graphics2D.setColor(new Color(18, 201, 18));
                    arrayListWithPoints.forEach((point -> graphics2D.fill(new Rectangle((point.x*25)+1,(point.y*25)+1,24,24))));
                    graphics2D.setColor(Color.green);
                    graphics2D.fill(new Rectangle((arrayListWithPoints.get(arrayListWithPoints.size()-1).x*25)+1,(arrayListWithPoints.get(arrayListWithPoints.size()-1).y*25)+1,24,24));
                    break;
                case 2:
                    graphics2D.setColor(new Color(9, 9, 190));
                    arrayListWithPoints.forEach((point -> graphics2D.fill(new Rectangle((point.x*25)+1,(point.y*25)+1,24,24))));
                    graphics2D.setColor(Color.blue);
                    graphics2D.fill(new Rectangle((arrayListWithPoints.get(arrayListWithPoints.size()-1).x*25)+1,(arrayListWithPoints.get(arrayListWithPoints.size()-1).y*25)+1,24,24));
                    break;
                case 3:
                    graphics2D.setColor(new Color(189, 189, 12));
                    arrayListWithPoints.forEach((point -> graphics2D.fill(new Rectangle((point.x*25)+1,(point.y*25)+1,24,24))));
                    graphics2D.setColor(Color.yellow);
                    graphics2D.fill(new Rectangle((arrayListWithPoints.get(arrayListWithPoints.size()-1).x*25)+1,(arrayListWithPoints.get(arrayListWithPoints.size()-1).y*25)+1,24,24));
                    break;
                case 4:
                    graphics2D.setColor(new Color(194, 11, 194));
                    arrayListWithPoints.forEach((point -> graphics2D.fill(new Rectangle((point.x*25)+1,(point.y*25)+1,24,24))));
                    graphics2D.setColor(Color.magenta);
                    graphics2D.fill(new Rectangle((arrayListWithPoints.get(arrayListWithPoints.size()-1).x*25)+1,(arrayListWithPoints.get(arrayListWithPoints.size()-1).y*25)+1,24,24));
                    break;
            }
        });




    }

    private void renderApple(ArrayList<Point> arrayWithApplePointInside, Graphics2D graphics2D) {
        graphics2D.setColor(Color.red);
        graphics2D.fill(new Rectangle((arrayWithApplePointInside.get(0).x*25)+1,(arrayWithApplePointInside.get(0).y*25)+1,24,24));
    }
}
