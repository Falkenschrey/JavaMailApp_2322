package de.snake.doit.gui;

import de.snake.doit.client.LobbyClient;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class DirectJoinLobby extends JFrame {
    private JTextField textFieldIP;
    private JPanel formDirectJoinLobby;
    private JButton joinButton;
    private JButton returnButton;

    public DirectJoinLobby() {
        this.setTitle("Direkt Beitreten");
        this.setContentPane(formDirectJoinLobby);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        joinButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new LobbyClient(textFieldIP.getText(),false);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new SearchLobby();
                    DirectJoinLobby.super.dispose();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
    }
}
