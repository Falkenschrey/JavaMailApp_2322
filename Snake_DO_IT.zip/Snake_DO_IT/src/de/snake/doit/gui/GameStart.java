package de.snake.doit.gui;

import de.snake.doit.client.GameClient;
import de.snake.doit.server.GameServer;
import de.snake.doit.util.Globals;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class GameStart extends JFrame {
    private JButton buttonSingleplayer;
    private JTextField textFieldName;
    private JPanel formGameStart;
    private JButton buttonMultiplayer;

    public GameStart() {
//        this.setLocationByPlatform(true);
        this.setTitle("Snake");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setContentPane(formGameStart);
        this.pack();
        this.setResizable(false);
        buttonMultiplayer.setBackground(new Color(238, 238, 238));
        buttonSingleplayer.setBackground(new Color(238, 238, 238));
        if (Globals.getNickname() != null){
            textFieldName.setText(Globals.getNickname());
        }else {
            textFieldName.setText("Bitte hier Namen eingeben");
            textFieldName.setDisabledTextColor(Color.gray);
            textFieldName.setEnabled(false);
        }
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        buttonMultiplayer.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {
                buttonMultiplayer.setContentAreaFilled(false);
                buttonMultiplayer.setForeground(new Color(51, 51, 51));
                buttonMultiplayer.setBorderPainted(true);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                buttonMultiplayer.setContentAreaFilled(true);
                buttonMultiplayer.setForeground(new Color(238, 238, 238));
                buttonMultiplayer.setBorderPainted(false);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                buttonMultiplayer.setBackground(Color.darkGray);
                buttonMultiplayer.setForeground(new Color(238, 238, 238));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                buttonMultiplayer.setBackground(new Color(238, 238, 238));
                buttonMultiplayer.setForeground(new Color(51, 51, 51));
            }
        });

        buttonSingleplayer.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {
                buttonSingleplayer.setContentAreaFilled(false);
                buttonSingleplayer.setForeground(new Color(51, 51, 51));
                buttonSingleplayer.setBorderPainted(true);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                buttonSingleplayer.setContentAreaFilled(true);
                buttonSingleplayer.setForeground(new Color(238, 238, 238));
                buttonSingleplayer.setBorderPainted(false);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                buttonSingleplayer.setBackground(Color.darkGray);
                buttonSingleplayer.setForeground(new Color(238, 238, 238));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                buttonSingleplayer.setBackground(new Color(238, 238, 238));
                buttonSingleplayer.setForeground(new Color(51, 51, 51));
            }
        });

        textFieldName.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                if (textFieldName.getText().equals("Bitte hier Namen eingeben")){
                    textFieldName.setText("");
                    textFieldName.setEnabled(true);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        buttonSingleplayer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                GameStart.super.dispose();
                ScheduledExecutorService service = Executors.newScheduledThreadPool(2);
                Runnable gameServer = () -> {
                    try {
                        new GameServer(true, 1);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                };
                Runnable gameClient = () -> {
                    try {
                        new GameClient("localhost", 500, true,1);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                };
                service.execute(gameServer);
                service.execute(gameClient);
            }
        });
        buttonMultiplayer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                if (!textFieldName.getText().equals("") && textFieldName.isEnabled()){
                    try {
                        Globals.setNickname(textFieldName.getText());
                        new SearchLobby();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    GameStart.super.dispose();
                } else {
                    JOptionPane.showMessageDialog(GameStart.super.getContentPane(),"Bitte Namen eingeben!");
                }
            }
        });
    }
}
