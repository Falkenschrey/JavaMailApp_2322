package de.snake.doit.client;

import de.snake.doit.protocol.MulticastServerToClient;
import de.snake.doit.util.Util;

import javax.swing.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public class SearchLobbyHandler {
    private HashMap<String,LobbyClientSide> hashMapForLobbys;
    private ObjectInputStream objectInputStream;
    private ByteArrayInputStream byteArrayInputStream;
    private MulticastSocket multicastSocket;
    private DatagramPacket datagramPacket;
    private byte[] inputBytes = new byte[512];
    private DefaultListModel<String> listModel;
    private ScheduledExecutorService service =  Executors.newScheduledThreadPool(1);

    public SearchLobbyHandler(DefaultListModel<String> listModel) throws IOException {
        this.hashMapForLobbys = new HashMap<>();
        this.listModel = listModel;
        this.multicastSocket = new MulticastSocket(42420);
        multicastSocket.setNetworkInterface(NetworkInterface.getByInetAddress(InetAddress.getByName(Util.lookUpOwnIpAddress())));
        service.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                try {
                    datagramPacket = new DatagramPacket(inputBytes,inputBytes.length);
                    multicastSocket.receive(datagramPacket);
                    byteArrayInputStream = new ByteArrayInputStream(inputBytes);
                    objectInputStream = new ObjectInputStream(byteArrayInputStream);
                    MulticastServerToClient multicastServerToClient = (MulticastServerToClient) objectInputStream.readObject();
                    if (!hashMapForLobbys.containsKey(multicastServerToClient.getIpAddressFromLobbyHost())){
                        hashMapForLobbys.put(multicastServerToClient.getIpAddressFromLobbyHost(),new LobbyClientSide(multicastServerToClient.getLobbyName() + " | Host: " + multicastServerToClient.getIpAddressFromLobbyHost(), multicastServerToClient.getIpAddressFromLobbyHost(), multicastServerToClient.getLobbyMembersJoined()));
                    } else {
                        hashMapForLobbys.get(multicastServerToClient.getIpAddressFromLobbyHost()).setClientsConnected(multicastServerToClient.getLobbyMembersJoined());
                        hashMapForLobbys.get(multicastServerToClient.getIpAddressFromLobbyHost()).resetTimeToLive();
                    }
                } catch (IOException | ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        },0,1,TimeUnit.MILLISECONDS);
    }


    public void updateListModel() throws IOException, ClassNotFoundException {
        reduceTimeToLive();
        removeTimedOutLobbys();
        hashMapForLobbys.forEach((ipKey, lobbyClientSide)->{
            if (!lobbyClientSide.isListed()){
                String addToListModel = lobbyClientSide.getName() + " | " + lobbyClientSide.getClientsConnected() + "/4";
                listModel.add(listModel.size()-1,addToListModel);
                lobbyClientSide.setListedAs(addToListModel);
                lobbyClientSide.setListed(true);
            } else {
                String updateListModelEntry = lobbyClientSide.getName() + " | " + lobbyClientSide.getClientsConnected() + "/4";
                listModel.set(listModel.indexOf(lobbyClientSide.getListedAs()),updateListModelEntry);
                lobbyClientSide.setListedAs(updateListModelEntry);
            }
        });
    }

    public void exit() throws IOException {
        if (objectInputStream != null){
            this.objectInputStream.close();
            this.byteArrayInputStream.close();
        }
        this.multicastSocket.close();
        this.service.shutdownNow();
    }

    private void removeTimedOutLobbys() {
        ArrayList<String> toRemove = new ArrayList<>();
        if (!hashMapForLobbys.isEmpty()){
            hashMapForLobbys.forEach((ipKey, lobbyClientSide)->{
                if (hashMapForLobbys.get(ipKey).getTimeToLive() == 0){
                    listModel.remove(listModel.indexOf(lobbyClientSide.getListedAs()));
                    toRemove.add(ipKey);
                }
            });
            toRemove.forEach((ipKey) -> hashMapForLobbys.remove(ipKey));
        }
    }

    private void reduceTimeToLive() {
        if (!hashMapForLobbys.isEmpty()){
            hashMapForLobbys.forEach((ipKey, lobbyClientSide)->{
                hashMapForLobbys.get(ipKey).reduceTimeToLive();
            });
        }
    }

    public String getSelectedLobbyIp(String selectedValue) {
        String[] selectedLobbyIp = new String[1];
        hashMapForLobbys.forEach((ipKey, lobbyClientSide) -> {
            if (Objects.equals(selectedValue, lobbyClientSide.listedAs)){
                selectedLobbyIp[0] = lobbyClientSide.getIpAddress();
            }
        });
        return selectedLobbyIp[0];
    }

    public int getConnectedClients(String selectedValue) {
        int[] selectedLobbyIp = new int[1];
        hashMapForLobbys.forEach((ipKey, lobbyClientSide) -> {
            if (Objects.equals(selectedValue, lobbyClientSide.listedAs)){
                selectedLobbyIp[0] = lobbyClientSide.getClientsConnected();
            }
        });
        return selectedLobbyIp[0];
    }

    private class LobbyClientSide {

        private String name;
        private String listedAs;
        private String ipAddress;
        private int clientsConnected;
        private int timeToLive;
        private boolean listed;

        public String getIpAddress() {
            return ipAddress;
        }

        public String getListedAs() {
            return listedAs;
        }

        public void setListedAs(String listedAs) {
            this.listedAs = listedAs;
        }

        public boolean isListed() {
            return listed;
        }

        public void setListed(boolean listed) {
            this.listed = listed;
        }

        public String getName() {
            return name;
        }

        public int getClientsConnected() {
            return clientsConnected;
        }
        public void setClientsConnected(int clientsConnected){
            this.clientsConnected = clientsConnected;
        }

        public int getTimeToLive() {
            return timeToLive;
        }
        public void resetTimeToLive(){
            this.timeToLive = 2;
        }
        public LobbyClientSide(String name, String ipAddress, int clientsConnected) {
            this.name = name;
            this.ipAddress = ipAddress;
            this.clientsConnected = clientsConnected;
            this.timeToLive = 2;
        }

        public void reduceTimeToLive(){
            this.timeToLive--;
        }
    }
}
