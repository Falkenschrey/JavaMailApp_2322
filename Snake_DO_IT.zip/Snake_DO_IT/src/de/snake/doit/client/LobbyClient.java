package de.snake.doit.client;


import de.snake.doit.gui.LoungeLobby;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class LobbyClient {
    private final Socket socketClient;
    private final ObjectInputStream objectInputStream;
    private final ObjectOutputStream objectOutputStream;
    private final LobbyClientHandler lobbyClientHandler;
    private final LoungeLobby loungeLobby;

    public LobbyClient(String hostAddress, boolean host) throws IOException {
        System.out.println("[Lobby-Client]Attempting Connection");
        this.socketClient = new Socket(hostAddress,667);
        this.objectOutputStream = new ObjectOutputStream(socketClient.getOutputStream());
        this.objectInputStream = new ObjectInputStream(socketClient.getInputStream());
        this.lobbyClientHandler = new LobbyClientHandler(objectInputStream, objectOutputStream, socketClient);
        System.out.println("[Lobby-Client]Connected");
        this.loungeLobby = new LoungeLobby(host, lobbyClientHandler);
    }
}
