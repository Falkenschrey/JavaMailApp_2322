package de.snake.doit.client;

import de.snake.doit.gui.CreateLobby;
import de.snake.doit.gui.LoungeLobby;
import de.snake.doit.gui.SearchLobby;
import de.snake.doit.protocol.LobbyToClient;
import de.snake.doit.protocol.LobbyToServer;
import de.snake.doit.protocol.objects.LobbyPlayer;
import de.snake.doit.util.Util;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class LobbyClientHandler {
    private ObjectInputStream objectInputStream;
    private ObjectOutputStream objectOutputStream;
    private Socket socketClient;
    private boolean closeLobby;
    private int kickID;
    public LobbyClientHandler(ObjectInputStream objectInputStream, ObjectOutputStream objectOutputStream, Socket socketClient) {
        this.objectInputStream = objectInputStream;
        this.objectOutputStream = objectOutputStream;
        this.socketClient = socketClient;
        this.closeLobby = false;
        this.kickID = 0;
    }

    public LobbyToClient getUpdates(LobbyPlayer lobbyPlayer, boolean leaveLobby, Boolean gameStart) throws IOException {
        try {
            LobbyToServer lobbyToServer = new LobbyToServer(lobbyPlayer,leaveLobby, gameStart);
            lobbyToServer.setCloseLobby(closeLobby);
            objectOutputStream.writeObject(lobbyToServer);
//            objectOutputStream.writeObject(new LobbyToServer(lobbyPlayer,leaveLobby));
            objectOutputStream.flush();
            objectOutputStream.reset();
            Object object = objectInputStream.readObject();
            LobbyToClient lobbyToClient = (LobbyToClient) object;
            return lobbyToClient;
        } catch (IOException | ClassNotFoundException e) {
            objectInputStream.close();
            objectOutputStream.close();
            socketClient.close();
            throw new RuntimeException(e);
        }
    }

    public void leaveLobby() throws IOException {
        objectInputStream.close();
        objectOutputStream.close();
        socketClient.close();
    }
    public void closeLobby(){
        this.closeLobby = true;
    }

    public String getOwnIpAddress(){
        return Util.getIpAddressFromByteArray(socketClient.getLocalAddress().getAddress());
    }
}
