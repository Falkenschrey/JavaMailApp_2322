package de.snake.doit.client;

import de.snake.doit.protocol.enums.Directions;
import de.snake.doit.protocol.GameToClient;
import de.snake.doit.protocol.GameToServer;

import java.awt.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

public class GameClientHandler {
    private final ObjectInputStream inputObject;
    private final ObjectOutputStream outputObject;
    private Directions direction;
    private Directions lastDirection;
    private Socket clientSocket;
    private boolean singlePlayer;
    private int slotID;

    public GameClientHandler(ObjectInputStream inputObject, ObjectOutputStream outputObject, Socket socketClient, int slotID, boolean singlePlayer){
        this.inputObject = inputObject;
        this.outputObject = outputObject;
        this.clientSocket = socketClient;
        this.singlePlayer = singlePlayer;
        this.slotID = slotID;
        switch (slotID){
            case 1:
                this.direction = Directions.UP;
                break;
            case 2:
                this.direction = Directions.RIGHT;
                break;
            case 3:
                this.direction = Directions.DOWN;
                break;
            case 4:
                this.direction = Directions.LEFT;
                break;
        }
        this.lastDirection = direction;
    }

    public void setDirection(Directions direction){
        this.direction = direction;
    }
    public Directions getLastDirection() {
        return lastDirection;
    }

    public HashMap<Integer, HashMap<Integer, ArrayList<Point>>> getRenderData() throws IOException, ClassNotFoundException {
        System.out.println("[GAMECLIENTHANDLER] EMFPANGE GAMETOCLIENTPACKET");
        GameToClient gameToClient = (GameToClient) inputObject.readObject();
        System.out.println("[GAMECLIENTHANDLER] GAMETOCLIENTPACKET EMFPANGEN");
        return generateRenderDataFromToClientObject(gameToClient, gameToClient.isGameOverFlag(slotID));
    }

    public void sendToServerObject(boolean isSinglePlayer) throws IOException {
        GameToServer gameToServer = new GameToServer(direction, isSinglePlayer, slotID);
        lastDirection = direction;
        System.out.println("[GAMECLIENTHANDLER] SENDE GAMETOSERVER PACKET");
        outputObject.writeObject(gameToServer);
        System.out.println("[GAMECLIENTHANDLER] GAMETOSERVERPACKET GESENDET");
        outputObject.flush();
        outputObject.reset();
    }

    private HashMap<Integer, HashMap<Integer, ArrayList<Point>> > generateRenderDataFromToClientObject(GameToClient gameToClient, boolean gameOver) {
        if (gameOver){
            HashMap< Integer , HashMap<Integer, ArrayList<Point>> > renderData = new HashMap<>();
            HashMap<Integer, ArrayList<Point>> gameScore = new HashMap<>();
            ArrayList<Point> gameScoreList = new ArrayList<>();
            gameScoreList.add(new Point(gameToClient.getGameScore(slotID), gameToClient.getGameScore(slotID)));
            gameScore.put(slotID, gameScoreList);
            renderData.put(3,gameScore);
            return renderData;
        }
//        HashMap<Integer, ArrayList<Point>> renderData = new HashMap<>();
        HashMap< Integer , HashMap<Integer, ArrayList<Point>> > renderData = new HashMap<>();
        ArrayList<Point> apple = new ArrayList<>();
        apple.add(gameToClient.getRenderApple());
        HashMap<Integer, ArrayList<Point>> appleHashMap = new HashMap<>();
        appleHashMap.put(0,apple);

        renderData.put(2, gameToClient.getRenderSnake());
        renderData.put(1,appleHashMap);
        return renderData;
    }

    public void sendStartPackage() throws IOException {
        if (singlePlayer) {
            outputObject.writeObject(GameToServer.generateInitialSinglePlayerPackage(slotID));
            outputObject.flush();
            outputObject.reset();
        } else {
            outputObject.writeObject(GameToServer.generateInitialMultiplayerPackage(direction, slotID));
            outputObject.flush();
            outputObject.reset();
        }
    }

    public void closeConnection() throws IOException {
        this.inputObject.close();
        this.outputObject.close();
        this.clientSocket.close();
    }
}
