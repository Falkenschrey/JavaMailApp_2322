package de.snake.doit.client;

import de.snake.doit.gui.GameBoard;
import de.snake.doit.gui.GameFrame;
import de.snake.doit.protocol.enums.Directions;

import javax.swing.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class GameClient {
    private final Socket socketClient;
    private final ObjectInputStream objectInputStream;
    private final ObjectOutputStream objectOutputStream;
    private final GameBoard gameBoard;
    private final JFrame frame;
    private final GameClientHandler gameClientHandler;

    public GameClient(String host,int size, boolean isSinglePlayer, int slotID) throws IOException {
        if (!isSinglePlayer){
            switch (slotID){
                case 1:
                    JOptionPane.showMessageDialog(JOptionPane.getRootFrame(),"Du hast die Farbe Grün und startest unten!");
                    break;
                case 2:
                    JOptionPane.showMessageDialog(JOptionPane.getRootFrame(),"Du hast die Farbe Blau und startest links!");
                    break;
                case 3:
                    JOptionPane.showMessageDialog(JOptionPane.getRootFrame(),"Du hast die Farbe Gelb und startest oben!");
                    break;
                case 4:
                    JOptionPane.showMessageDialog(JOptionPane.getRootFrame(),"Du hast die Farbe Magenta und startest rechts!");
                    break;
            }
        }
        System.out.println("[Client]Attempting Connection");
        this.socketClient = new Socket(host,666);
        this.objectOutputStream = new ObjectOutputStream(socketClient.getOutputStream());
        this.objectInputStream = new ObjectInputStream(socketClient.getInputStream());
        this.gameClientHandler = new GameClientHandler(objectInputStream, objectOutputStream, socketClient, slotID, isSinglePlayer);
        System.out.println("[Client]Connected");
        System.out.println("[Client]Generate Window");
        this.frame = new GameFrame(isSinglePlayer);
        this.gameBoard = new GameBoard(size,gameClientHandler, isSinglePlayer,this.frame,slotID);
        this.frame.add(gameBoard);
        this.frame.pack();
        frame.setLocationRelativeTo(null);

        this.frame.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case 40 -> {
                        if (!(gameClientHandler.getLastDirection() == Directions.UP)){
                            gameClientHandler.setDirection(Directions.DOWN);
                        }
                    }
                    case 39 -> {
                        if (!(gameClientHandler.getLastDirection() == Directions.LEFT)){
                            gameClientHandler.setDirection(Directions.RIGHT);
                        }
                    }
                    case 38 -> {
                        if (!(gameClientHandler.getLastDirection() == Directions.DOWN)){
                            gameClientHandler.setDirection(Directions.UP);
                        }
                    }
                    case 37 -> {
                        if (!(gameClientHandler.getLastDirection() == Directions.RIGHT)){
                            gameClientHandler.setDirection(Directions.LEFT);
                        }
                    }
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        System.out.println("[Client]Genarated Window");
    }
}
